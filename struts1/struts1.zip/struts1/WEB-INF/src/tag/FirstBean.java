package tag;

public class FirstBean {
    private SecondBean second = null;

    public SecondBean getSecond() {
        return second;
    }

    public void setSecond(SecondBean second) {
        this.second = second;
    }
}
