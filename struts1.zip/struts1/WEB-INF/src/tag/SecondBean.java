package tag;

public class SecondBean {
    private ThirdBean third = null;

    public ThirdBean getThird() {
        return third;
    }

    public void setThird(ThirdBean third) {
        this.third = third;
    }
}
